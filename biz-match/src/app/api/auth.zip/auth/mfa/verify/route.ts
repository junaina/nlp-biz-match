import { NextResponse } from "next/server";
import {
  supabaseFromBearerToken,
  getBearerTokenFromHeaders,
} from "@/lib/supabase/from-token";

export async function POST(req: Request) {
  const token = getBearerTokenFromHeaders(req);
  if (!token)
    return NextResponse.json(
      { error: "Missing Bearer token" },
      { status: 401 },
    );

  const { factorId, code } = await req.json().catch(() => ({}));
  if (!factorId || !code) {
    return NextResponse.json(
      { error: "factorId and code required" },
      { status: 400 },
    );
  }

  const supabase = supabaseFromBearerToken(token);

  const { data, error } = await supabase.auth.mfa.challengeAndVerify({
    factorId,
    code,
  });

  if (error)
    return NextResponse.json({ error: error.message }, { status: 400 });

  // data contains the updated session/auth state after successful verification
  return NextResponse.json({ ok: true, data });
}
